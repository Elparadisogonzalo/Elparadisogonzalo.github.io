The software contents of this repository are Copyright (c) Protocol Labs,
Licensed under the `Permissive License Stack`, meaning either of:

- Apache-2.0 Software License: https://www.apache.org/licenses/LICENSE-2.0
  ([...4tr2kfsq](https://gateway.ipfs.io/ipfs/bafkreiankqxazcae4onkp436wag2lj3ccso4nawxqkkfckd6cg4tr2kfsq))

- MIT Software License: https://opensource.org/licenses/MIT
  ([...vljevcba](https://gateway.ipfs.io/ipfs/bafkreiepofszg4gfe2gzuhojmksgemsub2h4uy2gewdnr35kswvljevcba))

You may not use the contents of this repository except in compliance
with one of the listed Licenses. For an extended clarification of the
intent behind the choice of Licensing please refer to
https://protocol.ai/blog/announcing-the-permissive-license-stack/

Unless required by applicable law or agreed to in writing, software
distributed under the terms listed in this notice is distributed on
an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
either express or implied. See each License for the specific language
governing permissions and limitations under that License.

<!--- SPDX-License-Identifier: Apache-2.0 OR MIT -->
`SPDX-License-Identifier: Apache-2.0 OR MIT`
