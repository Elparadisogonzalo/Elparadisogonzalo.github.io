# mhopts - multihash options for writing commands

`mhopts` is a small package that helps to write commands which
may take multihash options. Check it out in action:

- [multihash](../multihash)
- [hashpipe](https://github.com/jbenet/go-hashpipe)

Godoc: [https://godoc.org/github.com/multiformats/go-multihash/opts](https://godoc.org/github.com/multiformats/go-multihash/opts)
