# TLS handshake example

Run
```bash
go run cmd/tlsdiag.go server
```
