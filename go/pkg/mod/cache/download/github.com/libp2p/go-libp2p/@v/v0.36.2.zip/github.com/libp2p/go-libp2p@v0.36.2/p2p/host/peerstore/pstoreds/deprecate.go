// Deprecated: The database-backed peerstore will be removed from go-libp2p in the future.
// Use the memory peerstore (pstoremem) instead.
// For more details see https://github.com/libp2p/go-libp2p/issues/2329
// and https://github.com/libp2p/go-libp2p/issues/2355.
package pstoreds
