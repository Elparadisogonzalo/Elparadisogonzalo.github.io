# go-libp2p roadmap Q4’22/Q1’23

Please see our roadmap in [Starmap](https://starmap.site/roadmap/github.com/libp2p/go-libp2p/issues/1806#simple)

Please add any feedback or questions in: https://github.com/libp2p/go-libp2p/issues/1806