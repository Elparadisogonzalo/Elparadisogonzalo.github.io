# Git Hooks

This directory contains useful Git hooks for working with go-libp2p.

Install them by running
```bash
git config core.hooksPath .githooks
```
