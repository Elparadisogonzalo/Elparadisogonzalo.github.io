// SPDX-FileCopyrightText: 2023 The Pion community <https://pion.ly>
// SPDX-License-Identifier: MIT

// Package dtls implements Datagram Transport Layer Security (DTLS) 1.2
package dtls
