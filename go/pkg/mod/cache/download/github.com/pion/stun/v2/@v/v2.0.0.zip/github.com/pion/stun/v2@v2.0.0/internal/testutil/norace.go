// SPDX-FileCopyrightText: 2023 The Pion community <https://pion.ly>
// SPDX-License-Identifier: MIT

//go:build !race
// +build !race

package testutil

// Race reports if the race detector is enabled.
const Race = false
