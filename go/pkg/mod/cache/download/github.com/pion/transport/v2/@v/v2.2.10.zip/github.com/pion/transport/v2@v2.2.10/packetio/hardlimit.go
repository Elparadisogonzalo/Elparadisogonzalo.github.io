// SPDX-FileCopyrightText: 2023 The Pion community <https://pion.ly>
// SPDX-License-Identifier: MIT

//go:build packetioSizeHardlimit
// +build packetioSizeHardlimit

package packetio

const sizeHardLimit = true
