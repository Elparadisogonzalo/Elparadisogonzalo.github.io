/*
Package gen contains all commonly used generators and shrinkers.
*/
package gen
