/*
Package prop contains the most common implementations of a gopter.Prop.
*/
package prop
